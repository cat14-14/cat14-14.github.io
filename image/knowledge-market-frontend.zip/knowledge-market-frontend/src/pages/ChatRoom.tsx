import { useParams } from "react-router-dom";
import { useState } from "react";
export default function ChatRoom() {
  const { roomId } = useParams();
  const [messages, setMessages] = useState<string[]>([]);
  const [input, setInput] = useState("");
  function send() {
    if (!input.trim()) return;
    setMessages(m => [...m, input]);
    setInput("");
  }
  return (
    <section className="max-w-4xl mx-auto px-6 py-10 flex flex-col h-[80vh]">
      <h1 className="text-xl font-bold mb-4">채팅방 #{roomId}</h1>
      <div className="flex-1 border p-4 mb-4 overflow-y-auto space-y-2">
        {messages.map((m, idx) => (
          <div key={idx} className="bg-fg/5 px-3 py-2 rounded self-start max-w-[70%]">{m}</div>
        ))}
      </div>
      <div className="flex gap-2">
        <input className="flex-1 border p-2" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" and send()} placeholder="메시지 입력" />
        <button className="px-4 py-2 border rounded" onClick={send}>전송</button>
      </div>
    </section>
  );
}
