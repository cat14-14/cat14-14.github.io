import { Link } from "react-router-dom";
import { demoCourses } from "../mock/data";
export default function Home() {
  return (
    <main className="max-w-7xl mx-auto px-6 py-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
      {demoCourses.map(c => (
        <Link key={c.id} to={`/course/${c.id}`} className="group border border-fg/10 rounded overflow-hidden hover:shadow-lg transition-shadow">
          <img src={c.thumbnail} alt={c.title} className="aspect-video object-cover group-hover:scale-105 transition-transform" />
          <div className="p-4">
            <h2 className="font-semibold mb-1 line-clamp-2">{c.title}</h2>
            <p className="text-xs opacity-60 mb-2">{c.author}</p>
            <span className="text-sm font-medium">{c.price ? c.price.toLocaleString() + "원" : "무료"}</span>
          </div>
        </Link>
      ))}
    </main>
  );
}
