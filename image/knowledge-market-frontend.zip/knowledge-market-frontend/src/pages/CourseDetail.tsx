import { useParams } from "react-router-dom";
import { demoCourses } from "../mock/data";
export default function CourseDetail() {
  const { id } = useParams();
  const course = demoCourses.find(c => c.id === Number(id));
  if (!course) return <p className="p-10">강의를 찾을 수 없습니다.</p>;
  return (
    <article className="max-w-4xl mx-auto px-6 py-10">
      <img src={course.thumbnail} alt={course.title} className="w-full aspect-video object-cover rounded mb-6" />
      <h1 className="text-2xl font-bold mb-2">{course.title}</h1>
      <p className="opacity-70 mb-4">강사: {course.author}</p>
      <p className="whitespace-pre-line leading-relaxed mb-6">{course.description}</p>
      <button className="px-4 py-2 border rounded" onClick={() => alert("결제/수강은 백엔드 구축 후 지원")}>{course.price ? `${course.price.toLocaleString()}원 결제` : "무료 수강"}</button>
    </article>
  );
}
