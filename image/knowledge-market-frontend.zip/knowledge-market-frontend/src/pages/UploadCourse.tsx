import { useState } from "react";
export default function UploadCourse() {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [price, setPrice] = useState(0);
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    alert("백엔드 없이 로컬로 강의 저장은 생략 – 추후 API 연동");
  }
  return (
    <section className="max-w-xl mx-auto px-6 py-10">
      <h1 className="text-xl font-bold mb-6">새 강의 업로드 (stub)</h1>
      <form className="space-y-4" onSubmit={handleSubmit}>
        <input required className="w-full border p-2" placeholder="강의 제목" value={title} onChange={e => setTitle(e.target.value)} />
        <textarea required className="w-full border p-2 h-32" placeholder="강의 설명" value={desc} onChange={e => setDesc(e.target.value)}></textarea>
        <input type="number" className="w-full border p-2" placeholder="가격(원) – 0은 무료" value={price} onChange={e => setPrice(Number(e.target.value))} />
        <button className="px-4 py-2 border rounded" type="submit">업로드</button>
      </form>
    </section>
  );
}
