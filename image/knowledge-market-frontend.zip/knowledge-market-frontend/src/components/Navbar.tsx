import { NavLink } from "react-router-dom";
import UserMenu from "./UserMenu";
export default function Navbar() {
  return (
    <header className="border-b border-fg/10 sticky top-0 bg-bg/95 backdrop-blur-sm">
      <nav className="max-w-7xl mx-auto flex items-center justify-between px-6 py-3">
        <h1 className="text-xl font-bold tracking-tight">KNOWLEDGE&nbsp;MKT</h1>
        <div className="flex items-center gap-6 text-sm font-medium">
          <NavLink to="/" className={({ isActive }) => (isActive ? "underline" : "")}>피드</NavLink>
          <NavLink to="/upload" className={({ isActive }) => (isActive ? "underline" : "")}>강의 업로드</NavLink>
          <NavLink to="/chat/general" className={({ isActive }) => (isActive ? "underline" : "")}>채팅</NavLink>
          <UserMenu />
        </div>
      </nav>
    </header>
  );
}
