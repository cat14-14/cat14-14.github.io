import { useAuthStore } from "../store/useAuthStore";
export default function UserMenu() {
  const { token, setToken } = useAuthStore();
  if (!token)
    return (
      <button className="px-3 py-1 border rounded" onClick={() => alert("로그인 기능은 추후 구현")}>로그인</button>
    );
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs opacity-60">demo-user</span>
      <button className="text-xs underline" onClick={() => setToken(null)}>로그아웃</button>
    </div>
  );
}
