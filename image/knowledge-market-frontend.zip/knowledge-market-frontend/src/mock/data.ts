export const demoCourses = [
  {
    id: 1,
    title: "C 언어 포인터 완벽 가이드",
    author: "은호 김",
    price: 0,
    thumbnail: "https://placehold.co/600x400?text=C+Pointer",
    description: "포인터의 개념부터 실전 문제까지 한 번에!"
  },
  {
    id: 2,
    title: "Unity 3D 캐릭터 애니메이션 기초",
    author: "Lee Min",
    price: 12000,
    thumbnail: "https://placehold.co/600x400?text=Unity+Anim",
    description: "강의 + 실습 프로젝트 파일 제공"
  }
];
