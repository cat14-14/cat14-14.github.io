import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import CourseDetail from "./pages/CourseDetail";
import UploadCourse from "./pages/UploadCourse";
import ChatRoom from "./pages/ChatRoom";

export default function App() {
  return (
    <div className="min-h-screen bg-bg text-fg">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/course/:id" element={<CourseDetail />} />
        <Route path="/upload" element={<UploadCourse />} />
        <Route path="/chat/:roomId" element={<ChatRoom />} />
      </Routes>
    </div>
  );
}
